# temperature_humidity_indicator
Temperature &amp; Humidity indicator using 7-segment LCD, STM8L152C6 and SHT21
